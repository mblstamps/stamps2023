# R intro - STAMPS 2023!

Hello!
In this directory you'll find 
- 4 numbered .Rmd files to work through,
	-  .html versions if you'd prefer to open the documents in your browser
- .Rmd of the slide deck. 
- a folder called "data/", with 2 .txt files inside



After the intro lecture, please go ahead and open up the first .Rmd, and work through them at your own pace. Please ask questions at any time, this evening or later in the course.


